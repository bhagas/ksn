<div class="row">
	<div class="page-header">
		<h2>Peraturan</h2>
	</div>
</div>

<div class="row centered">
		<div class="box1 grey-bg centered centered">	
			<a class="no-decor" href="?page=peraturandetail&konten=provinsi"><img class="" src="images/artikel.png"><br><h4>Provinsi Jateng</h4></a>
		</div>
		<div class="box1 grey-bg centered">	
			<a class="no-decor" href="?page=peraturandetail&konten=magelang"><img src="images/komentar.png"><br><h4>Kabupaten Magelang</h4></a>
		</div>
		<div class="box1 grey-bg centered centered">	
			<a class="no-decor" href="?page=peraturandetail&konten=klaten"><img class="" src="images/artikel.png"><br><h4>Kabupaten Klaten</h4></a>
		</div>
		<div class="box1 grey-bg centered">	
			<a class="no-decor" href="?page=peraturandetail&konten=boyolali"><img src="images/komentar.png"><br><h4>Kabupaten Boyolali</h4></a>
		</div>
<div class="page-header">
	<h2>Perpres</h2>
</div>
<div class="row centered">
		<div class="box1 grey-bg centered centered">	
			<a class="no-decor" href="?page=perpres&kawasan=merapi"><img class="" src="images/artikel.png"><br><h4>Kawasan Merapi</h4></a>
		</div>
		<div class="box1 grey-bg centered">	
			<a class="no-decor" href="?page=perpres&kawasan=borobudur"><img src="images/komentar.png"><br><h4>Kawasan Borobudur</h4></a>
		</div>
</div>
</div>