<?php $user=$_SESSION['name'];?>

<div class="row">
	<div class="col-md-12 centered">
			<h2>Selamat Datang <?php echo ucfirst($user);?></h2>
		
		<hr>
		<div class="box-info centered">
			<strong>Silahkan Pilih Menu Kiri Atas Untuk Menampilkan Pilihan</strong>
		</div>
		</div>
</div>