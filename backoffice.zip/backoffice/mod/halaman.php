<div class="page-header">
	<h2>Manajemen Halaman</h2>
</div>
<div class="row centered">
		<div class="box1 grey-bg centered centered">	
			<a class="no-decor" href="?page=rencana"><img class="" src="images/artikel.png"><br><h4>RTRW</h4></a>
		</div>
		<div class="box1 grey-bg centered">	
			<a class="no-decor" href="?page=ksn"><img src="images/komentar.png"><br><h4>Rencana Tata Ruang KSN</h4></a>
		</div>
		<div class="box1 grey-bg centered centered">	
			<a class="no-decor" href="?page=rencana"><img class="" src="images/artikel.png"><br><h4>RTRKSP</h4></a>
		</div>
		<div class="box1 grey-bg centered">	
			<a class="no-decor" href="?page=ksn"><img src="images/komentar.png"><br><h4>Program</h4></a>
		</div>
</div>