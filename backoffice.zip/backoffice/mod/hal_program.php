<div class="page-header">
	<h2>Prioritas Pembangunan</h2>
</div>
<div class="row centered">
		<div class="box1 grey-bg centered centered">	
			<a class="no-decor" href="?page=program&kawasan=merapi"><img class="" src="images/artikel.png"><br><h4>Kawasan Merapi</h4></a>
		</div>
		<div class="box1 grey-bg centered">	
			<a class="no-decor" href="?page=program&kawasan=borobudur"><img src="images/komentar.png"><br><h4>Kawasan Borobudur</h4></a>
		</div>
</div>