<div class="row">
	<div class="page-header">
		<h2>Profil Wilayah</h2>
	</div>
</div>

<div class="row centered">
		<div class="box1 grey-bg centered centered">	
			<a class="no-decor" href="?page=profildetail&konten=provinsi"><img class="" src="images/artikel.png"><br><h4>Provinsi Jateng</h4></a>
		</div>
		<div class="box1 grey-bg centered">	
			<a class="no-decor" href="?page=profildetail&konten=magelang"><img src="images/komentar.png"><br><h4>Kabupaten Magelang</h4></a>
		</div>
		<div class="box1 grey-bg centered centered">	
			<a class="no-decor" href="?page=profildetail&konten=klaten"><img class="" src="images/artikel.png"><br><h4>Kabupaten Klaten</h4></a>
		</div>
		<div class="box1 grey-bg centered">	
			<a class="no-decor" href="?page=profildetail&konten=boyolali"><img src="images/komentar.png"><br><h4>Kabupaten Boyolali</h4></a>
		</div>

</div>