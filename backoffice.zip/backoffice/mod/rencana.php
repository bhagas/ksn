<div class="row">
	<div class="page-header">
		<h2>Rencana Tata Ruang Wilayah</h2>
	</div>
</div>
<div class="row centered">
		<div class="box1 grey-bg centered centered">	
			<a class="no-decor" href="?page=rtrw&konten=nasional"><img class="" src="images/artikel.png"><br><h4>RTRW Nasional</h4></a>
		</div>
		<div class="box1 grey-bg centered">	
			<a class="no-decor" href="?page=rtrw&konten=jawa-bali"><img src="images/komentar.png"><br><h4>RTRP Jawa-Bali</h4></a>
		</div>
		<div class="box1 grey-bg centered centered">	
			<a class="no-decor" href="?page=rtrw&konten=provinsi"><img class="" src="images/artikel.png"><br><h4>RTRW Provinsi Jateng</h4></a>
		</div>
		<div class="box1 grey-bg centered">	
			<a class="no-decor" href="?page=kabupaten"><img src="images/komentar.png"><br><h4>RTRW Kabupaten</h4></a>
		</div>

</div>