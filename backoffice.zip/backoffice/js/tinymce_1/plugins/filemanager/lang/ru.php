<?php
define('lang_Select','Выбрать');
define('lang_Erase','Удалить');
define('lang_Open','Открыть');
define('lang_Confirm_del','Уверены, что хотите удалить этот файл?');
define('lang_All','Все');
define('lang_Files','Файлы');
define('lang_Images','Изображения');
define('lang_Archives','Архивы');
define('lang_Error_Upload','Загружаемый файл превышает допустимый размер.');
define('lang_Error_extension','Недопустимый формат файла.');
define('lang_Upload_file','Загрузить файл');
define('lang_Filter','Фильтр');
define('lang_Videos','Видео');
define('lang_Music','Музыка');
define('lang_New_Folder','Новая папка');
define('lang_Folder_Created','Папка успешно создана');
define('lang_Existing_Folder','Существующая папка');
define('lang_Confirm_Folder_del','Уверены, что хотите удалить эту папку и все файлы в ней?');
define('lang_Return_Files_List','Вернуться к списку файлов');
define('lang_Preview','Просмотр');
define('lang_Download','Загрузить');
define('lang_Insert_Folder_Name','Введите имя папки:');
define('lang_Root','Корневая папка');
?>
