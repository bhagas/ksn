<?php
define('lang_Select','Избери');
define('lang_Erase','Изтрий');
define('lang_Open','Отвори');
define('lang_Confirm_del','Сигурни ли сте, че искате да изтриете този файл?');
define('lang_All','Всичко');
define('lang_Files','Файлове');
define('lang_Images','Изображения');
define('lang_Archives','Архиви');
define('lang_Error_Upload','Каченият файл надминава максимално разрешената големина.');
define('lang_Error_extension','Това файлово разширение не е позволено.');
define('lang_Upload_file','Качете файл');
define('lang_Filter','Папка');
define('lang_Videos','Видео');
define('lang_Music','Музика');
define('lang_New_Folder','Нова папка');
define('lang_Folder_Created','Папката е правилно създадена');
define('lang_Existing_Folder','Съществуваща папка');
define('lang_Confirm_Folder_del','Сигурни ли сте, че искате да изтриете папката и всичко, което се съдържа с нея?');
define('lang_Return_Files_List','Връщане към списъка с файлове');
define('lang_Preview','Преглед');
define('lang_Download','Свали');
define('lang_Insert_Folder_Name','Въведете име на папката:');
define('lang_Root','root');
?>
