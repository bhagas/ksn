<!-- <OBJECT data="upload/program/magelang.pdf" TYPE="application/x-pdf" TITLE="SamplePdf" 
WIDTH=200 HEIGHT=100>
    <a href="upload/program/magelang.pdf">shree</a> 
</object> -->
<iframe src="upload/program/magelang.pdf" width="80%" height="1000"></iframe>